
text=" my friend si sa"
with open("C:\\Users\\Asus\\OneDrive - American International University-Bangladesh\\Desktop\\bbb.txt",'w') as file :
     file.write(text)
