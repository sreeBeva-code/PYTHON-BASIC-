class car:
    def speed(self):
        print("240 ms/h in road")
class bus:
    def speed(self):
        print("180 ms/h i road")
def vecspeed(obj):
   obj.speed()

c=car()
vecspeed(c)

b=bus()
vecspeed(b)