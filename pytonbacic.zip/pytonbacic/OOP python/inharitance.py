#class Person:
 # def __init__(self, fname, lname):
  ## self.lastname = lname

#  def printname(self):
 #   print(self.firstname, self.lastname)

#class Student(Person):
 # pass

#x = Student("Mike", "Olsen")
#x.printname()

#multi -lavel
#class orgern:
  #def orgman(self):
#class man(orgern):
#  def manlt(self):
  #  print("man from orgen")
#class women(man):
  #def twomen(self):
#     print("women form orgewr")
#ob=  women()
#ob.manlt()

#mutiple......

class object:
    def things(self):
        print("thing is a object")
class toy:
    def ball(self):
        print("kids pay by ball")
class animal(object,toy):
    def mult(self):
        print(" this is multiple imn haritance")
am=animal()
am.things()
am.ball()
