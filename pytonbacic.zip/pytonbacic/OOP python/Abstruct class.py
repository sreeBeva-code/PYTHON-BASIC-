from abc import ABC,abstractmethod
class human(ABC):
    @abstractmethod
    def lifetime(self):
        pass
    def country(self):
        print("hello everybody")

class father(human):
    def lifetime(self):
        print("he is alayws  loyel for his father")
class son(human):
    def lifetime(self):
         print("every chiled nit loyel for his family")
f=father()
s=son()
f.lifetime()
f.country()
s.lifetime()
s.country()
