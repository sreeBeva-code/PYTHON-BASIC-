class  Person:
    slnum=5 #class variable

    def __init__(self,age,job,salary,id):
        self.age=age  #instan variable
        self.job=job
        self.salary=salary
        self.id=id
    def brave(self):
        print("he emlopye of the year in "+self.job)
    def quts(self):
        print("every body loves him")