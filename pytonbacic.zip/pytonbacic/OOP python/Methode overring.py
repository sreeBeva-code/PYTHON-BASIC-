"""""
class Animal:

    def eat(self):
        print("This animal is eating")

class Rabbit(Animal):

    def eat(self):
        print("This rabbit is eating a carrot")


rabbit = Rabbit()
rabbit.eat()
"""
#methode chaine
class object:
    def thing(self):
        print("this is a ob")
        return  self
    def use(self):
        print("this is useable")
        return  self
    def toutch(self):
        print("is this tautchable?")
        return self
op=object()
op.use().thing().toutch()
