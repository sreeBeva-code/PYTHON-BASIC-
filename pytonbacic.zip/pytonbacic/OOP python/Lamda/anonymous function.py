sum=lambda x,y:x+y
print(sum(5,6))
multi=lambda x,y:(3*4)
print(multi(7,2))
fullname=lambda first_name,lastname:first_name+" "+lastname
print(fullname("bevan","saha"))
#defult value

defu=lambda x,y=14:x+y
print(defu(5,3))

# statement
ageck=lambda age: True if age>= 18  else  False
print(ageck(13))




