car=["bmw","auddi ","ford"]
car.sort()
print(car)
numcar=[("bmw" ,26,"car"),
        ("audi",5,"motorbike"),("ford",11,"micar")]
age=lambda ages:ages[1]
numcar.sort(key=age)# i usehere reverse =true
print(numcar)



