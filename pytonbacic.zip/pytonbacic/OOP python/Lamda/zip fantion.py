#zip (italeble ) alw of zip funtion
name=("bevan","sikender5", "sowrav","sadnan")
city=("dhaka","b-baria ","barisal","nrayangonaj")
gf=("none","akhi","aisharjo","saroni")
man=zip(name,city,gf)
print(man)

