# it selct only condition data
li =(1,3,4,5,6)
result=filter(lambda  x:x%5 !=0,li)
print(list(result))
# tru false funtion
ages = [5, 12, 17, 18, 24, 32]

def myFunc(x):
  if x < 18:
    return False
  else:
    return True

adults = filter(myFunc, ages)
for x in adults:
  print(x)
