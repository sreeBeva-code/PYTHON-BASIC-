import functools
num=("b","e","v","a","n")
sum=(functools.reduce(lambda x,y:x+y,num))
print(sum)




