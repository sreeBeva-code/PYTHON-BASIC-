#syntext map(fun , iter num)
# 1stc code by funtion
def  her(x):
    return x*x
num =(2,4,6,10)
reslt=list(map(her,num))
print(reslt)

#lamda use
bevan = [1,2,3,4,5]
sum=list(map(lambda x:x+x,bevan))
print(sum)
#
num1=[1,4,5,6,7]
num2=[2,6,7,8,9]
mult=list(map(lambda x,y:x*y,num1,num2))
print(mult)


