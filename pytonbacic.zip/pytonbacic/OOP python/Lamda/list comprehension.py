#Syntax:   newList = [ expression(if/else) for element in oldList if condition ]
List = []

# Traditional approach of iterating
for character in 'Geeks 4 Geeks!':
    List.append(character)

# Display list
print(List)
# list com
student= [100.40,5,30,80,35,60]
sum=[i if i >=45 else "fail" for i in student  ]
print(sum)
