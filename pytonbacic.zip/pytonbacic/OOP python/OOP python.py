from Employe  import Person

per1=Person(20,"swft","20k",2-43144-1)
print( per1.age)
Person.slnum=4
per1.brave()
per1.quts()
print(per1.slnum)