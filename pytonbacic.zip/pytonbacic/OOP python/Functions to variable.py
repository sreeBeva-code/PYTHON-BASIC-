def hello():
    print("bevan")

print(hello) #it sow our fungtion memory location
name=hello
name()
