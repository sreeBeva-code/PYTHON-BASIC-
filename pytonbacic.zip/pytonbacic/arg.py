def bevan(name,**kwargs):
    print(name)

    for i ,j in kwargs.items() :

        print(i,j)

bevan(name="Bevan" ,age=20 ,sub="bangla")

