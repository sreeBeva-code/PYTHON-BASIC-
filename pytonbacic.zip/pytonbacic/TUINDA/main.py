print("hello world")
b=5
c=3
d=1
print(b,c,d)