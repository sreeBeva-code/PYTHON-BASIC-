x=12
y=13.40
z="16"
x=float(x)
y=int(y)
#z=int(z)
print(x)
print(y)
print(z)
print("my home no is "+ z) #  after + alw string