#string method
name="bEvan saha"
#print(len(name))

#print(name.find("b"))
#print(name.find("v"))
print(name.count("s"))
print(name.capitalize())
print(name.isdigit())
print(name.isalpha())
print(name.lower())
print(name.replace("b","z"))
print(name*4)




