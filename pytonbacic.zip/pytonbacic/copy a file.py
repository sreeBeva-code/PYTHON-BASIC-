import  shutil
shutil.copyfile("C:\\Users\\Asus\\OneDrive - American International University-Bangladesh\\Desktop\\bbb.txt","C:\\Users\\Asus\\OneDrive - American International University-Bangladesh\\Desktop\\bevan.txt")


