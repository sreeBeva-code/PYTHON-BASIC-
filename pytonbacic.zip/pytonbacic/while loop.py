name="bevan"
while len(name)==5:
    name=input("what is our name:")
    print("how are you "+name)
