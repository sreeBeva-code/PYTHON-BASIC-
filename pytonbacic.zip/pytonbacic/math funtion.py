#math funtion
#import math  // when you use math funtion you must be import math
import math

x=14
y=15
z=100
print(max(x,y,z))
print(min(x,y,z))
print(math.sqrt(12))
t=math.pi
print(t)
tt=-123
yy=abs(-345)
print(math.fabs(tt))
print(yy)

