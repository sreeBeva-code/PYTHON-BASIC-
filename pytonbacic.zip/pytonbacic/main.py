#print("my name is bevan ")
#print("sadand sikander is my best friend")
#name="bevan"
#x=28
#print(x)
#type detact andf type custing
stage=12
lastage=12
totalage=stage+lastage
print(type(totalage))
stage+=1
print(stage)
print("my first age is "+str(stage))




