#function is a method where3 is
#def  pyfunction(name) :
   # print("my namre is bevan "+name)
    #age=str(input(print("your age is:")))
    #id=float(input(print("plz your id")))


#pyfunction("bevan" )

#returen stetment
#def addition(a,b):
  #  c=a+b
    #return c
#a=int(input("valueof first no:"))
#b=int(input("value of secn no"))
#c=addition(a,b)
#print(c)

#key word nested function
def wood():
     def bell():
       print("saha")
     bell()
print("my name is bevan")
wood()






