#list =ia a put multiple value in a brackets

#Vaichele=["car","bus","truck","van"]  list declr
#Vaichele[0]="tomtom" whitch point list decl

#Vaichele.append("ricshaw") # add elimentg
#Vaichele.sort()# sl wise
#Vaichele.pop() #remive last element
#Vaichele.clear()# all eliment clear
#Vaichele.insert(2,"bike")
#Vaichele.remove("truck")

#print(Vaichele)


# 2d -list
food=["mango","banaqna","cake"]
vec=["bus","car","bike"]
sub=["bangla","english","msath"]
element=[food,vec,sub]
print(element[0][0])
print(element[0][1])
print(element[0][2])
print(element[1][0])
print(element[1][1])
print(element[1][2])
print(element[2][0])
print(element[2][1])
print(element[2][2])





