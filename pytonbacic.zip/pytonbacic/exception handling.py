
try:
    x = int(input("plz input your number"))
    y = int(input("plz 2nd number"))
    print(x/y)

except ZeroDivisionError:
    print("not divided by zero")
except ValueError:
    print( "invalid literal for int()")
except Exception as  v:
    print(v)
else:
    print("you arestupid mashin")

finally:
    print("try agin")
    








