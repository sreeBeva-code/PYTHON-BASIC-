#phon="bevan=saha"
#for i in  phon:
  #  if i=="=":
    #    continue
    #print(i,end="")

for j in range(1,13):
    if j==4:
        pass
    else:
        print(j)

while True:
    inp=input("name")
    if inp!="":
        break









