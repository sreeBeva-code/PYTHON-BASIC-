import os
src="saba.txt"
destination= "C:\\Users\\Asus\\OneDrive - American International University-Bangladesh\\Desktop\\saba.txt"

try:
    if os.path.exists(destination):
        print("the file already hair")
    else:
        os.replace(src,destination)
        print("the file is moved")
except FileNotFoundError:
    print(src+"was not found")
