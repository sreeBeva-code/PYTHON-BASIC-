name="bevan saha"
print(name[2:])# start =0---------in
print(name[:-2]) #m=m(-2)+1
print(name[:5:2])# whitch eliment you print
#another way
slice=slice(2,-4)
print(name[slice])
