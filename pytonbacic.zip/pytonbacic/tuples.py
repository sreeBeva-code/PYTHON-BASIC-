tuple=("name","bevan","sifat",25,"name")
print(tuple.count("name"))
print(tuple.index("sifat"))
#tuple is simelar to list
# its value is not changeable
#need to less time
# need to less memorey




