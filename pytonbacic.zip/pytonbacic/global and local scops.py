#local variable
#l=10 # global variable
##def game_no(n):
   #l=5
   #global l

   #l=l+15
   #print(l)

#game_no("my nuber is")


#for nested function
l=30
def  bevan():
       l=20
       def sad():
        global l
         l=10
        print(l)
        sad()

bevan()
print(l)



