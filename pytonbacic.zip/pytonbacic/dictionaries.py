
info={"sikander ":"fuck boy",
      "sadnan":"playboy"
      ,"srserstha ":"magi","badhon":"clicbaz"}
info.update({"bevan":"good"})

print(info)
#print(info["sikander "])
#print(info.values())
#print(info.keys())
#print(info.items())

