name =input("what is your name ")
id=input("what is your id ?")
age=int(input("what is your age "))
hight=float(input("haw tall are you:"))
age=age+1
print("whats up "+name)
print("oh great, your id  is "+id)
print("your age is"+str(age))
print("you are so tall"+str(hight)+"cm")

