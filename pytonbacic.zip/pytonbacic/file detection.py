import os
path="C:\\Users\\Asus\\OneDrive - American International University-Bangladesh\\Desktop\\ffol"
if os.path.exists(path):
    print("this file is in  my desktop")
    if os.path.isfile(path):
        print("yes this is a file")
    elif os.path.isdir(path):
        print("yes is this directorey")
else:
      print("no more in desktop")