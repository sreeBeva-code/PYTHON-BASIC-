#logical oparetor (and ,end,age)= are used
temp=float(input("todays temp"))
if temp >=20 and temp <=50:
    print("very hot")
elif temp < 20 or temp>10:
    print("cold today")
if not (temp < 20 or temp>10):
    print("random")