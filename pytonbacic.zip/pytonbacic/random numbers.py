import random
x=random.randint(5,8)
print(x)
y=random.random()
print(y)
card=[3,4,5,6,3,8,1,56,"bevan","sad","j","r","t"]
#print(random.choice(card))
random.shuffle(card)
print(card)


