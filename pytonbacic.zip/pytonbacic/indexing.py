
# INDEXING IS semilar to list slicing
animal=["cow","dog","cat","moncey"]
print(animal.index("moncey"))
print(animal.index("cat"))
name ="bevan  saha"
firstname=name[-1].upper()
print(firstname)
lastname=name[0:11].upper()
print(lastname)




