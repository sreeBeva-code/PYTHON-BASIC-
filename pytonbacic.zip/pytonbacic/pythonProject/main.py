import os,shutil
source="saba.txt"
destination= "C:\\Users\\Asus\\OneDrive - American International University-Bangladesh\\Desktop\\saba.txt"

try:
         if os.path.exists(destination):
             print("the file already hair")
         else:
            shutil.copyfile(source, destination)
            print("the file is moved")


except FileNotFoundError:
    print(source+"was not found")