#import time

#for  seconds in range(10,0,-1):
  #  print(seconds)
    #time.sleep(1)
    #print("happy")
#raw=int(input("raw nam"))
#coloam=int(input("collam "))
#symble=input("stm")
#for i in range(raw):
  #  for j in range(coloam):
    #    print(symble, end="+")
#print()
#for i in  range(1,6):
  #  for j in range(1,6):
    #    print("#",end="")
    #print("")

#for i in  range(1,6):
  #  for j in range(i)://(1,i+1)/(i+1)
    #    print("#",end="")
    #print("")

#for i in  range(5,0,-1):
  #  for j in range(1,i+1):
    #    print("#",end="")
    #print("")



