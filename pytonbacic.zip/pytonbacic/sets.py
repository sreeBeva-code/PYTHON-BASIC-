subject={"math,","bangla","english"}
ca={"car","bus","vaa","english"}
#print(ca.intersection(subject))
#print(ca.union(subject))

print(subject.update(ca))




