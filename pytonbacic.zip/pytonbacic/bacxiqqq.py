#print(" name is bevan ")
#print("sadand sikander is  best friend")

#x=28
#print(x)
#type detact andf type custing
#stage=12
#lastage=12
#totalage=stage+lastage
#print(type(totalage))
#stage+=1
#print(stage)
#print(" first age is "+str(stage))
#float data type
#hight=130.44
#lenth=44.5
#hight+=lenth
#print(hight)
#print(type(hight))
#print(str(hight))
#bool  =


