name=input("What is your name")
age=int (input("How old are you:"))
if age>=35:
    print("you are selected for vaccine ")
elif age==18:
    print(" you are apply for vacccine")
else:
    print("you are not for vaccine")
