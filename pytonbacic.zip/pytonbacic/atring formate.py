
#str.format =is a ofsinal function

#name ="bevan"
#title="saha"
#print("my first name is {} and sar name is {}".format(name,title))
#print("my first name is {} and sar name is {}".format(title,name))
#print("my first name is {0} and sar name is {1}".format(title,name))#positional
#print("my first name is {1} and sar name is {1}".format(title,name))
#print("i am stude in {sub}and my ambition is i should job in {com}".format(sub="cse",com="microsoft"))
#sikander="he is my  best {} and his the {}"
#print(sikander.format("friend","playboy"))


# now for number space
#name="sik"
#print("my name is {}".format(name))
#print("my name is {:<10}".format(name))
#print("my name is {:>10}".format(name))
#print("my name is {:^10}".format(name))
#print("my name is {:10}".format(name))


# for number
numbe=3.1416
count=5000
print("the pi number is {:.2f}".format(numbe))
print("the pi number is {:.3f}".format(count))
print("the pi number is {:o}".format(count))
print("the pi number is {:b}".format(count))
print("the pi number is {:x}".format(count))
print("the pi number is {:d}".format(count))
print("the pi number is {:E}".format(count))












