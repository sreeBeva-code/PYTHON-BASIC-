bishnu=True
print(bishnu)
print(type(bishnu))
huimortal=False
print(huimortal)
print(type(huimortal))
#type casting
print(str(bishnu))
