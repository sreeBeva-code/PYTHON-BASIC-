#regular
#name=bevan
#age =21
#human=True
#print(name)
#print(age)
#print(human)

#muliple
sar_name,p_age,lady= "saha" , 20 ,False
print(sar_name)
print(p_age)
print(lady)
#rule 2
sadnan=bevan=sikanr=30
print(sadnan,sikanr,bevan)
#rule3


 fruite  =["bmw", "merc", "aude"]
 x,y,f=fruite
 print(x,y,f)


